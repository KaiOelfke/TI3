#ifndef _MM_H

void* my_malloc(int byteCount);
void my_free(void* p);
void status();

#define _MM_H

#endif 
